$(function() {
  var FADE_TIME = 150; // ms

  // Initialize variables
  var $window = $(window);
  var $usernameInput = $('.usernameInput'); // Input for username
  var $messages = $('.messages'); // Messages area
  var $inputMessage = $('.inputMessage'); // Input message input box

  var $loginPage = $('.login.page'); // The login page
  var $chatPage = $('.chat.page'); // The chatroom page

  // Prompt for setting a username
  var username;
  var connected = false;
  var $currentInput = $usernameInput.focus();

  
  //gambling cash
  var myPosition;
  var cash = 0;  //betting cash
  var cashBet = 0;
  var myCash;
  var socket = io();

  // Sets the client's username
  function setUsername () { // Vince editing
    username = cleanInput($usernameInput.val().trim());

    // If the username is valid
    if (username) {
      $loginPage.fadeOut();
      $chatPage.show();
      $loginPage.off('click');
      $currentInput = $inputMessage.focus();

      // Tell the server your username
      socket.emit('add user', username);
    }
  }

  // Prevents input from having injected markup
  function cleanInput (input) {
    return $('<div/>').text(input).text();
  }
  
	function changeStatus(i, n, current, bets, pot){
		if(n < 0){
			$('#name' + i).css("background-color", "white");
			$('#status' + i).text('');
			$('#blind' + i).text('');
		}
		else if(n == 0){
			$('#name' + i).css("background-color", "gray");
			$('#status' + i).text('Folded');
			$('#blind' + i).text('');
		}
		else if(n == 1){
			$('#name' + i).css("background-color", "white");
			$('#status' + i).text('Called');
			$('#blind' + i).text('$ ' + bets[i-1]);
		}
		else if(n == 2){
			$('#name' + i).css("background-color", "white");
			$('#status' + i).text('Bet');
			$('#blind' + i).text('$ ' + bets[i-1]);
		}
		else if(n == 3){
			$('#name' + i).css("background-color", "cyan");
			$('#status' + i).text('ALL IN');
			$('#blind' + i).text('$ ' + bets[i-1]);
		}
		else if(n == 4){
			$('#name' + i).css("background-color", "green");
			$('#status' + i).text('Winner');
			$('#blind' + i).text('$ ' + pot);
			$('#pot').text(0);
		}
		//testing $(".betting").text(i + '' + current + ' ' + n + '' + myPosition );
		if(current == i-1 && n != 4){
			$('#name' + i).css("background-color", "yellow");
		}
		if(myPosition == current){
			$("button").prop('disabled', false);
		}
	}
  //------------------------------------------------------------------
  //start of poker code;
	function updateList(users, usersCash, status, dealer, current, bets, pot ){
	   //currently does nothing with dealer
		myPosition = users.indexOf(username);
		myCash = usersCash[myPosition];	
		// test code$("#test").text(users.indexOf(username));
		for(i = 1; i <= users.length; i++){ // NEVER DO WRONG ARRAY SIZE
			$('#nameid' + i).text(users[i-1]);
			$('#cash' + i).text('$ ' + usersCash[i-1]);
			changeStatus(i, status[i-1], current, bets, pot);
		}
		for(i = users.length + 1; i <= 9; i++){
			$('#nameid' + i).text('');
			$('#cash' + i).text('');
			$('#name' + i).css("background-color", "white");
			$('#status' + i).text('');
			$('#blind' + i).text('');
		}
	}
	
	function updateUserCards(card1, card2){
		var v = card1.val, s = card1.suite;
			$('#hand1').attr("src", 'images/Playing Cards/' + v + s + '.png');
			v = card2.val;
			s = card2.suite;
			$('#hand2').attr("src", 'images/Playing Cards/' + v + s + '.png');
	}
	function updateTableCards(tableCards){
		for(i=0; i < tableCards.length; i++){
			$('#table' + (i+1)).attr("src", 'images/Playing Cards/' + tableCards[i].val + tableCards[i].suite + '.png');
		}
	}

  $window.keydown(function (event) {
    // Auto-focus the current input when a key is typed
    if (!(event.ctrlKey || event.metaKey || event.altKey)) {
      $currentInput.focus();
    }
    // When the client hits ENTER on their keyboard
    if (event.which === 13) {
      if (!username) { //VINCE added !
       // sendMessage();
        //socket.emit('stop typing');
        //typing = false;
      //} else {
        setUsername();
      }
    }
  });

  // Click events

  // Focus input when clicking anywhere on login page
  $loginPage.click(function () {
    $currentInput.focus();
  });

  // Focus input when clicking on the message input's border
  $inputMessage.click(function () {
    $inputMessage.focus();
  });
 
	$('#bet1').click(function () {
	if(cash + 10 <= myCash){
	  $('.betting').text(cash += 10);
	}
	});
    $('#bet2').click(function () {
	if(cash + 50 <= myCash){
	  $('.betting').text(cash += 50);
	}
	});
    $('#bet3').click(function () {
	if(cash + 100 <= myCash){
	  $('.betting').text(cash += 100);
	}
	});
    $('#bet4').click(function () {
	if(cash + 500 <= myCash){
	  $('.betting').text(cash += 500);
	}
	});
    $('#clr').click(function () {
	  $('.betting').text(cash = 0);
	});
      $('#bet').click(function () {
		socket.emit('made move', {
			move: 1, bet: cash
		});
	  $('.betting').text(0);
	  cash = 0;
	});
  
	$('#call').click(function () {
		socket.emit('made move', {
			move: 0, bet: myCash
		});
		$('.betting').text(0);
		cash = 0;
	});
    $('#fold').click(function () {
		socket.emit('made move', {
			move: 2
		});
		$('.betting').text(0);
		cash = 0;
	});
    $('#all').click(function () {
		socket.emit('made move', {move: 3, bet: myCash});
		$('.betting').text(0);
		cash = 0;
	});  
	
	$('#start').click(function () {
		socket.emit('begin game');
	});  
	
	$('#name1').click(function () {
	  socket.emit('winner chosen', 0);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name2').click(function () {
	  socket.emit('winner chosen', 1);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name3').click(function () {
	  socket.emit('winner chosen', 2);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name4').click(function () {
	  socket.emit('winner chosen', 3);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name5').click(function () {
	  socket.emit('winner chosen', 4);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name6').click(function () {
	  socket.emit('winner chosen', 5);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name7').click(function () {
	  socket.emit('winner chosen', 6);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name8').click(function () {
	  socket.emit('winner chosen', 7);
	  $('.nametag').css('pointer-events', 'auto');
	});
	$('#name9').click(function () {
	  socket.emit('winner chosen', 8);
	  $('.nametag').css('pointer-events', 'auto');
	});
  // Socket events

  // Whenever the server emits 'user joined', log it in the chat body
	socket.on('change username', function (data) {
		username = data.un;
	});
	
	$('.nametag').css('pointer-events', 'none');
	
	socket.on('update list', function (data) {
		$("button").prop('disabled', true); 
		$('#pot').text(data.pot);
		updateList(data.users, data.cash, data.status, data.dealer, data.cur, data.bets, data.pot);
	});
	
	socket.on('update user cards', function (data){
		updateUserCards(data.card1, data.card2);
	});
	
	socket.on('update table cards', function (data){
		updateTableCards(data.cards);
	});
	socket.on('clear table', function (){
		for(i=1; i < 6; i++){
			$('#table' + (i)).attr("src", 'images/Playing Cards/back.png');
		}
			$('#hand1').attr("src", 'images/Playing Cards/back.png');
			$('#hand2').attr("src", 'images/Playing Cards/back.png');
			$('#revealHands').html(' ');
	});

	function showCards(cards, suites, playing, users){
		var s = '';
		//------------------$('#test').text(cards + ' ' + suites  + 'playing: ' + playing );
		for(i=0; i < playing.length; i++){
			var card1v = cards[i][0], card2v = cards[i][1], card1s = suites[i][0], card2s = suites[i][1];
			s += playing[i] + ' ' + '<img src="images/Playing Cards/' + card1v + card1s + '.png" style="height:150%">';
			s += ' ' + '<img src="images/Playing Cards/' + card2v + card2s + '.png" style="height:150%">';
		}
		
		$('#revealHands').html(s);
	}
	socket.on('show cards', function (data) {
		showCards(data.cards, data.suites, data.playing, data.users);
	});
  // Whenever the server emits 'user left', log it in the chat body
	socket.on('user left', function (data) {
    //log(data.username + ' left');
    //addParticipantsMessage(data);
    //removeChatTyping(data);
	removedPlayer(data.users);
	});
	
	socket.on('game start', function (data) {
		$('#startbtn').html('');
	});
	
	socket.on('goto next', function (data) {
		$('#name' + (data.current + 1)).css("background-color", "white");
		$('#name' + (data.next + 1)).css("background-color", "yellow");
	});
	
	socket.on('game in progress', function () {
		$("body").html('<img src="images/hang.jpg"><br>game is already in progress');
	});
	
	socket.on('pick a winner', function () {
		$('.nametag').css('pointer-events', 'auto');
	});
	
	socket.on('disable buttons', function () {
		$("button").prop('disabled', true); 
	});
	
	socket.on('enable buttons', function () {
		$("button").prop('disabled', false); 
	});
	
	socket.on('enable start', function () {
		$("#start").prop('disabled', false);
	});
	
	socket.on('end round', function () {
		$('#start').text("End Round");
	});
	
	socket.on('lost screen', function () {
		$("body").html('<img src="images/hang.jpg"><br>better luck next time');
	});
  socket.on('disconnect', function () {

  });

  socket.on('reconnect', function () {
    log('you have been reconnected');
    if (username) {
      socket.emit('add user', username);
    }
  });

  socket.on('reconnect_error', function () {
    log('attempt to reconnect has failed');
  });

});
