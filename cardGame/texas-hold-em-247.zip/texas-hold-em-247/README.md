Vincent Finn 

Texas hold em card game web app built for fun and so I could play with a few friends on their phones.

-- How to play

go to the website https://texas-hold-em-247.herokuapp.com/ and type a username. The first player who joins will be the "driver", turns should end them selves, but if everyone went and it gets stuck,
this player can click end round on the bottom and all cards will be played. The driver is also responsible for clicking the box with the winner when the round is over, as there is no card scoring engine yet.


This app took about a week to make and I am satisfied with how it turned out, but I also know that I can do much better. I started this project on my own to learn more about javascript, jquery, and socket.io.
If I were to do it again I would have a much better idea of how to design the code and seperate the code into multiple files and better organize it overall.