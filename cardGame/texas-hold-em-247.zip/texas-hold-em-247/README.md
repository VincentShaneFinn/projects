
texas holdem card game.

currently a work in progress. 

Right now players can go to the website and wait until someone clicks start on the button left corner, then it gives that player the dealer,
and proceeds to distribute cards to everyone. the current player (yellow) can click call to go to next player and a new round begins after the round would normally be over.


