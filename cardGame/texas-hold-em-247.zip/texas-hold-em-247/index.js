// Setup basic express server
var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var port = process.env.PORT || 3000;

server.listen(port, function () {
  console.log('Server listening at port %d', port);
});

// Routing
app.use(express.static(__dirname + '/public'));

// Chatroom

var gameStart = false;
var numUsers = 0;
var clients = [];
var players = [];
var cash = [];
var status = []; // -1, white, 0 folded gray, 1 called, 2 bet, 3 all in blue, 4 win green
var bets = [];
var dealer = -1;
var currentPlayer = -1; // change to yellow if current player after status check
var foldedPlayers = [];
var allInPlayers = [];  // if a player clicks all in or goes all in from calling or big blinding to all in, add their index and cash bet to this so they get only this times # of players at the end of the round
var saveAllIn = [];
var multUser = 1;
var blankCards = {val: 'blank', suite: '' }
//card game variables
var handCount = 0;
var turnCount = 0;
var roundCount = 0;
var deck = []; // 0 - 13 is 1 - Ace values and suites clubs, diamonds, hearts, spades
var currentDeck = [];
var playerCards = [];
var tableCards = [];
var currentPot = 0;
var highestBet = 0; // every new round set to big blind and send to everyone so they have to at least call it or fold, and adds their bet to this value.
var bb = 40;
var sb = 20;
var playersPlaying = [];

var aPlayerBet = false;
var currentPlayerBetting;
io.sockets.on('connection', function (socket) {
	var addedUser = false;
	
	function updateList(){
		io.emit('update list', {
			users: players,
			cash: cash,
			status: status,
			dealer: dealer,
			cur: currentPlayer,
			bets: bets,
			pot: currentPot
		});
		
		clients[0].emit('enable start');
	}
	
	function initDeck(){
		
		for(i = 0; i < 13; i++){
			for(j = 0; j < 4; j++){		
				var card = new Object();
				card.val = i;
				card.suite = j;
				deck.push(card);
			}
		}
	}
	
	function shuffleDeck(){
		var m = deck.length, t, i;

		while (m) {
			i = Math.floor(Math.random() * m--);
			t = deck[m];
			deck[m] = deck[i];
			deck[i] = t;
		}
		currentDeck = deck.slice();
	}
	
	function dealCard(){
		var pCard = new Object();
		pCard = currentDeck[0];
		currentDeck.splice(0, 1);
		return pCard;
	}
	
	function updateUserCards(){
		for(i = 0; i < numUsers; i++){
			clients[i].emit('update user cards', {
				card1: playerCards[i][0],
				card2: playerCards[i][1]
				});
		}
	}
	
	function distributeDeck(){
		//take out the cards and send to player
		if(turnCount == 0){
			for(j = 0; j <= numUsers; j++){	
				arr = [];
				arr.push(dealCard());
				arr.push(dealCard());
				playerCards.push(arr);
			}	
			updateUserCards();
		}
	}
	
	function playTableCard(){
		tableCards.push(dealCard());
		io.emit('update table cards', {
			cards: tableCards
		});		
	}
	function clearTable(){
		tableCards = [];
		io.emit('clear table');
	}

  // when the client emits 'add user', this listens and executes
  socket.on('add user', function (username) {
	if (addedUser) return;
	if(gameStart){
		socket.emit('disable buttons');
	}
	else{
		// we store the username in the socket session for this client
		if (players.indexOf(username) >= 0){
			username = username + multUser;
			multUser++;
			socket.emit('change username', {
			un: username
			});
		}
		socket.username = username;
		socket.bet = 0;
		++numUsers;
		clients.push(socket); 
		players.push(username);
		cash.push(2000);
		status.push(-1);
		bets.push(0);
		addedUser = true;
		// echo globally (all clients) that a person has connected
		updateList();
		io.emit('enable start');
	}
	});
	
	function nextCurrentPlayer(){

		
		if(currentPlayer == numUsers - 1){
			currentPlayer = 0;
				if(foldedPlayers.includes(currentPlayer) || allInPlayers.includes(currentPlayer) && !aPlayerBet){
					if(foldedPlayers.length + allInPlayers.length >= numUsers - 1){
									currentPlayer = -1;
			if(turnCount == 0){
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 1){
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 2){
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
			}
				return;	}
					
					else{
					nextCurrentPlayer();
					}
				}
			}
		else{
			currentPlayer++;
				if(foldedPlayers.includes(currentPlayer) || allInPlayers.includes(currentPlayer)){
					if(foldedPlayers.length + allInPlayers.length >= numUsers - 1 && !aPlayerBet){
				currentPlayer = -1;
			if(turnCount == 0){
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 1){
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 2){
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
			}
					return;}
					else{
					nextCurrentPlayer();
					}
				}
			}
	}
	
	function allIn(p, bet){
		allInPlayers.push(p);
		saveAllIn.push(bet);
		status[p] = 3;
		aPlayerBet = true;
	}
	function getBigBlind(){
		//get next after dealer and bet 20 or as muchas they have, set highestBet to big blind
		var bPlayer = (dealer + 1) % numUsers;
		if(cash[bPlayer] - bb <= 0){
			bets[bPlayer] = bb - cash[bPlayer];
			cash[bPlayer] = 0;
			currentPot += bets[bPlayer];
			if(bets[bPlayer] >= highestBet){
				highestBet = bets[bPlayer];
			}
			allIn(bPlayer, bets[bPlayer]);
		}
		else{
			cash[bPlayer] = cash[bPlayer] - bb; 
			bets[bPlayer] = bb;
			currentPot += bets[bPlayer];
			highestBet = bets[bPlayer];
			status[bPlayer] = 2;
		}
	}
	
	function getLittleBlind(){
		var sPlayer = (dealer + 2) % numUsers;
		if(cash[sPlayer] - sb <= 0){
			bets[sPlayer] = sb - cash[sPlayer];
			cash[sPlayer] = 0;
			currentPot += bets[sPlayer];
			if(bets[bPlayer] > highestBet){
				highestBet = bets[sPlayer];
			}
			allIn(sPlayer, bets[sPlayer]);
		}
		else{
			cash[sPlayer] = cash[sPlayer] - sb; 
			bets[sPlayer] = sb;
			currentPot += bets[sPlayer];
			status[sPlayer] = 2;
		}
	}
	
	socket.on('made move', function(data){
		//when you bet we need the bet from user and subtract from total in cash[] and update list, update pot, highest bet if > highest bet BUG WARNING WHAT IF SOMEONE BETS LOWER THAN CURRENT HIGHEST BET
		//when call, need to  match the current
		var p = getPlayerIndex();
		//everytime a player comes here add one to handCount, if handCount >= playersPlaying (numUsers - foldPlayers.length - allInPlayers.length
		if(data.move == 0){ //called
			if(cash[p] - highestBet <= 0){ //check for all in
			    currentPot += highestBet - cash[p];
				bets[p] += highestBet - cash[p];
				if(bets[p] > highestBet){
					highestBet = bets[p];
				}
				cash[p] = 0;
				allIn(p, bets[p]);
			}
			else{
				cash[p] -= highestBet - bets[p];
				currentPot += highestBet -bets[p];
				bets[p] += highestBet - bets[p];		
				status[p] = 1;
				if(foldedPlayers.length + allInPlayers.length >= numUsers - 1){
					nextTurn();
				}
			}
		}
		if(data.move == 1){//bet
			if(data.bet + highestBet > cash[p]){ //check for all in
				currentPot += highestBet - cash[p];
				bets[p] += highestBet - cash[p];
				cash[p] = 0;
				if(bets[p] > highestBet){
					highestBet = bets[p];
				}
				allIn(p, bets[p]);
			}
			else{
				cash[p] -= data.bet + highestBet - bets[p];
				currentPot += data.bet + highestBet - bets[p];
				bets[p] += data.bet + highestBet - bets[p];
				
				if(bets[p] > highestBet){
					highestBet = bets[p];
				}
				status[p] = 2;
				if(data.bet > 0){
				aPlayerBet = true;
				if(currentPlayerBetting == currentPlayer){
					highestBet = 0;
				}
				currentPlayerBetting = currentPlayer;
				}
			}
		}
		if(data.move == 2){ // folded
			foldedPlayers.push(p);
			removePlaying(p);
			handCount--;
			status[p] = 0
		}
		if(data.move == 3){ //all In
			cash[p] = 0;
			currentPot += data.bet + highestBet - bets[p];
			bets[p] += data.bet + highestBet - bets[p];
			if(bets[p] > highestBet){
				highestBet = bets[p];
			}
			allIn(p, bets[p]);
			aPlayerBet = true;
			if(currentPlayerBetting == currentPlayer){
				highestBet = 0;
			}
			currentPlayerBetting = currentPlayer;
			handCount--;
		}
		
		playerMove();	
		
		if(turnOver()){
			nextTurn();
		}
	
	});
	
	function playerMove(){
		if(foldedPlayers.length + allInPlayers.length >= numUsers - 1 && !aPlayerBet){
			currentPlayer = -1;
			if(turnCount == 0){
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
				return;
			}
			if(turnCount == 1){
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
				return;
			}
			if(turnCount == 2){
				playTableCard(); 
				calculateWinner();
				return;
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
				return;
			}
		}
		else{
		try {
		nextCurrentPlayer();
		} catch (ex) {
			if(turnCount == 0){
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
				return;
			}
			if(turnCount == 1){
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
				return;
			}
			if(turnCount == 2){
				playTableCard(); 
				calculateWinner();
				return
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
				return;
			}
		}
		updateList();
		handCount++;
		}
	}
	
	function turnOver(){
		if (handCount >= numUsers - foldedPlayers.length - allInPlayers.length){
			return true;
		}
		if(foldedPlayers.length + allInPlayers.length >= numUsers - 1 && !aPlayerBet){
				if(turnCount == 0){
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
				return true;
			}
			if(turnCount == 1){
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
				return true;
			}
			if(turnCount == 2){
				playTableCard(); 
				calculateWinner();
				return true;
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
				return true;
			}
				}

		return false;
	}
	
	// this is when all players this hand have made a decision and we need to set current bet to 0, add 3 cards, then 1 then 1, then calcute winner and go to next round
	function nextTurn(){	
		handCount = 0;
		if(!aPlayerBet){
			turnCount++;
				if(foldedPlayers.length + allInPlayers.length < numUsers - 1){
					for(i=0; i < bets.length; i++){
						bets[i] = 0;
						if(status[i] == 1 || status[i] == 2){
							status[i] = -1;
						}
					}
					if(turnCount == 1){
						playTableCard();
						playTableCard();
						playTableCard();
					}
					if(turnCount == 2){
						playTableCard();
					}
					if(turnCount == 3){
						setTimeout(function() { playTableCard(); }, 0);
					}
					if(turnCount == 4){
						calculateWinner();
						return;
					}
					highestBet = 0;
				}
					//if there is one player, who is not folded or all in, play the rest of the cards and calculate winner
				
				}
				
			else{
			aPlayerBet = false;
			}
			updateList();
		}
	function showCards(){
		try{var cardsVal = [], cardsSuite = [];
		for(i = 0; i < playersPlaying.length; i++){
			var twocards = [], twosuites = [];
			twocards.push(playerCards[players.indexOf(playersPlaying[i])][0].val);
			twocards.push(playerCards[players.indexOf(playersPlaying[i])][1].val);
			twosuites.push(playerCards[players.indexOf(playersPlaying[i])][0].suite);
			twosuites.push(playerCards[players.indexOf(playersPlaying[i])][1].suite);
			cardsVal.push(twocards);
			cardsSuite.push(twosuites);
		}
		io.emit('show cards', { 
		cards: cardsVal,
		suites: cardsSuite,
		playing: playersPlaying, 
		users: players 
		});
		}
		catch(ex){
			
		}
	}
	//this function should get a score for everyone who is playing and give the money to the winner, (special case if one player alls in and 2 more are betting), then leaves winner green for 2 secs, and plays next round
	function calculateWinner(){
		var winner = 0;
		currentPlayer = -1;
		showCards();
		
		updateList();
		io.emit('disable buttons');
		clients[0].emit('pick a winner');
	}
	
	socket.on('winner chosen', function(winner) {
		if(allInPlayers.includes(winner) && (saveAllIn[allInPlayers.indexOf(winner)] * playersPlaying.length < currentPot)){
			status[winner] = 4;
			if(currentPot > 0){
				cash[winner] += saveAllIn[allInPlayers.indexOf(winner)] * playersPlaying.length;
			}
			currentPot = currentPot - (saveAllIn[allInPlayers.indexOf(winner)] * playersPlaying.length);
			allInPlayers.splice(winner, 1);
			updateList();
			if(currentPot <=0){
				setTimeout(function() { nextRound(); }, 4000);
			}
		}
		else{
			status[winner] = 4;
			if(currentPot > 0){
				cash[winner] += currentPot;
			}
			updateList();
			setTimeout(function() { nextRound(); }, 4000);
		}
	});
	function nextRound(){
		//set new dealer, currentPlayer, big blind?, small blind?
		if(roundCount > 0){
			setNextDealer();
		}	
		if(roundCount == 20){
			bb = 80;
			sb = 40;
		}
		if(roundCount == 40){
			bb = 160;
			sb = 80;
		}
		if(roundCount == 60){
			bb = 320;
			sb = 180;
		}
		currentPlayer = dealer;		
		roundCount++;
		//reset all variables that need to be default every round
		defaultValues();
		for(i = 0; i < numUsers; i++){
			if(cash[i] <= 0){
				clients[i].emit('lost screen');
				clients[i].disconnect();
			}
		}
		distributeDeck();
		getBigBlind();
		getLittleBlind();
		updateList();
	}
	
	function defaultValues(){
		shuffleDeck();
		playerCards = [];
		bets = [];
		clearTable();
		handCount = 0;
		turnCount = 0;
		defaultStatus();
		foldedPlayers = [];
		allInPlayers = [];
		saveAllIn = [];
		currentPot = 0;
		highestBet = 0; 
		playersPlaying = players.slice();
		aPlayerBet = false;	
		currentPlayerBetting = -1;
	}
	
	function defaultStatus(){
		for(i = 0; i < numUsers; i++){
			status[i] = -1;
			bets[i] = 0;
		}
	}
		//actually we need to put this in a different fucntion ^
	socket.on('begin game', function () {
		
	if(gameStart){
			currentPlayer = -1;
			if(turnCount == 0){
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 1){
				playTableCard(); 
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 2){
				playTableCard(); 
				calculateWinner();
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
			}
			return;	
		}
		
		else{
		gameStart = true;
		clients[0].emit('end round');
		socket.broadcast.emit('game start'); // just hides start button		
		dealer = getPlayerIndex();
		currentPlayer = dealer;
		initDeck();
		nextRound();
		updateList();
		}
	});
	
	//will have to rewrite to handle when a player reaches 0 dollars
    socket.on('user lost', function () {
		socket.emit('lost screen');
		socket.disconnect();
	});
	
	//notes on disconnect, if dealer leaves give dealer to previous, if player left index is < dealer, give to previous
	//if currentPlayer leaves, give to next available player, and update list, if not the current player, just update list
	//if player folded, or is in all in status, make remove their index from folded/allIn lists, splice index from each list
	
  // when the user disconnects.. perform this
	socket.on('disconnect', function () {
    if (addedUser) {
		--numUsers;
	  var index = players.indexOf(socket.username);		

	  givePreviousDealer(index);
	  setNextCurrentPlayer(index);
	  players.splice(index, 1);
	  cash.splice(index, 1);
	  clients.splice(index, 1);
	  status.splice(index, 1);
	  bets.splice(index, 1);
	  playerCards.splice(index, 1);
	  foldedPlayers.splice(index,1);
	  removePlaying(index);
	  
	  if(foldedPlayers.length + allInPlayers.length >= numUsers - 1 && !aPlayerBet && gameStart){
			if(turnCount == 0){
				playTableCard();
				playTableCard();
				playTableCard();
				playTableCard();
				playTableCard();
				calculateWinner();
			}
			if(turnCount == 1){
				playTableCard();
				playTableCard();
				calculateWinner();
			}
			if(turnCount == 2){
				playTableCard();
				calculateWinner();
			}
			if(turnCount == 3){
				calculateWinner(); // still need to calculate winner if one person called an all in player
			}
		}
		else{
	  if(clients.length > 0 && gameStart){
	  clients[currentPlayer].emit('enable buttons');
	  }
      //echo globally that this client has left
		updateList();
		if(!gameStart){
			io.emit('enable start');
		}
    }
	}
	});
	//when a player who was dealer disconnects, give dealerto previous player
	function setNextDealer(){
		if(dealer == numUsers - 1){
			dealer = 0;
		}
		else{
			dealer++;
		}
	}
	function givePreviousDealer(index){
		if(index == dealer){
			if(dealer == 0){
				dealer = numUsers - 2;
			}
			else if(index < dealer){
				dealer--;
			}
		}
	}
	
	function setNextCurrentPlayer(index){
		var folded = true;
		var i;
		if(index == currentPlayer){
			if(index >= numUsers){ 	
				i = 0;
				while(folded){
				handCount++;
				if(turnOver()){
					nextTurn();
				}
				if(foldedPlayers.includes(i)){
					i++;
				}
				else{
					folded = false;
				}
			}
				currentPlayer = i;
			}	  	  
		}
		else if (index < currentPlayer){
			if(currentPlayer == numUsers){
				i = 1;
				while(folded){
					if(foldedPlayers.includes(currentPlayer - i )){
					i++;
					}
					else{
						folded = false;
					}
				}
			  currentPlayer -= i;
			}
			else{
				i = 1;
				while(folded){
					if(foldedPlayers.includes(currentPlayer - i )){
					i++;
					}
					else{
					folded = false;
					}
				}
			  currentPlayer -= i;
			} 
		}
	}
	//really only used to get index of whoever just went or disconnected
	function getPlayerIndex(){
		return  players.indexOf(socket.username);
	}
	function removePlaying(p){
		return playersPlaying.splice(playersPlaying.indexOf(players[p]),1);
	}
});


